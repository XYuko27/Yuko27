module.exports = {
  tokenBot: "Your_Token_Bot",
  ownerID: "Your_Id",
};
